import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule,Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CustomerComponent } from './customer/customer.component';
import { OrderComponent } from './order/order.component';
import { ProductsComponent } from './products/products.component';
import { CartComponent } from './cart/cart.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CardComponent } from './card/card.component';
import { ListComponent } from './list/list.component';
import { MapComponent } from './map/map.component';
import { NewcustomerComponent } from './newcustomer/newcustomer.component';
import { Customerdetail1Component } from './customerdetail1/customerdetail1.component';
import { CustomerorderComponent } from './customerorder/customerorder.component';
import { EditcustomerComponent } from './editcustomer/editcustomer.component';
import { ViewbasketballComponent } from './viewbasketball/viewbasketball.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { PageComponent } from './page/page.component';



const appRoutes: Routes=[
  {path:'Customer',component:CustomerComponent },
  {path:'Order',component:OrderComponent },
  {path:'Products',component:ProductsComponent },
  {path:'Cart',component:CartComponent },
  {path:'About',component:AboutComponent },
  {path:'Login',component:LoginComponent },
  {path:'Card',component:CardComponent },
  {path:'List',component:ListComponent },
  {path:'Map',component:MapComponent },
  {path:'Newcustomer',component:NewcustomerComponent },
  {path:'Customerdetail1',component:Customerdetail1Component },
  {path:'Customerorder',component:CustomerorderComponent },
  {path:'Editcustomer',component:EditcustomerComponent },
  {path:'Viewbasketball',component:ViewbasketballComponent },
  {path:'Checkout',component:CheckoutComponent },
  {path:'Page',component:PageComponent },
  ];

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    OrderComponent,
    ProductsComponent,
    CartComponent,
    AboutComponent,
    LoginComponent,
    CardComponent,
    ListComponent,
    MapComponent,
    NewcustomerComponent,
    Customerdetail1Component,
    CustomerorderComponent,
    EditcustomerComponent,
    ViewbasketballComponent,
    CheckoutComponent,
    PageComponent,
  ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
