import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerdetail1',
  templateUrl: './customerdetail1.component.html',
  styleUrls: ['./customerdetail1.component.css']
})
export class Customerdetail1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
