import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Customerdetail1Component } from './customerdetail1.component';

describe('Customerdetail1Component', () => {
  let component: Customerdetail1Component;
  let fixture: ComponentFixture<Customerdetail1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Customerdetail1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Customerdetail1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
