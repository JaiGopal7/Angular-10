import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerorder',
  templateUrl: './customerorder.component.html',
  styleUrls: ['./customerorder.component.css']
})
export class CustomerorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
