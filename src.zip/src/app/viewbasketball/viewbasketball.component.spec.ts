import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewbasketballComponent } from './viewbasketball.component';

describe('ViewbasketballComponent', () => {
  let component: ViewbasketballComponent;
  let fixture: ComponentFixture<ViewbasketballComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewbasketballComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewbasketballComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
