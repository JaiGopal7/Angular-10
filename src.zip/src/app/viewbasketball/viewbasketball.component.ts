import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbasketball',
  templateUrl: './viewbasketball.component.html',
  styleUrls: ['./viewbasketball.component.css']
})
export class ViewbasketballComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
