import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  template:`
  MENU <ul>
  <li> <a [routerLink] = "['/customer']" > Customer </a> </li>
  <li> <a [routerLink] = "['/order']" > Order </a> </li>
  <li> <a [routerLink] = "['/products']" > Product </a> </li>
  <li> <a [routerLink] = "['/cart']" > Cart </a> </li>
  <li> <a [routerLink] = "['/about']" > About Me </a> </li>
  <li> <a [routerLink] = "['/login']" > Login </a> </li>
  <li> <a [routerLink] = "['/card']" > Card View </a> </li>
  <li> <a [routerLink] = "['/list']" > List View </a> </li>
  <li> <a [routerLink] = "['/map']" > Map View </a> </li>
  <li> <a [routerLink] = "['/newcustomer']" > New Customer </a> </li>
  <li> <a [routerLink] = "['/customerdetail']" > Customer Detail </a> </li>
  <li> <a [routerLink] = "['/customerorder']" >Customer order </a> </li>
  <li> <a [routerLink] = "['/editcustomer']" >Edit Customer </a> </li>
  <li> <a [routerLink] = "['/viewbasketball']" >View Details </a> </li>
  <li> <a [routerLink] = "['/checkout']" > Proceed to Checkout </a> </li>
  <li> <a [routerLink] = "['/page']" > Pagination </a> </li>
  <hr><hr>
  <router-outlet></router-outlet>
`
})
export class AppComponent {
  title = 'customermanager';
}
